
package com.service;

/*import java.util.List;

import com.model.ExamModify; 

public interface ExamModifyService {
	public void addExamModify(ExamModify exam);

	public List<ExamModify> getAllExamModify();

	public void deleteExamModify(Integer exam_id);

	public ExamModify getExamModify(int exam_id);

	public ExamModify updateExamModify(ExamModify exam);

}
*/
import java.util.List;

import com.model.QuesAdding;

public interface QuesAddingService {
	
	public void addQuesAdding(QuesAdding ques);

	public List<QuesAdding> getAllQuesAdding();

	public void deleteQuesAdding(Integer Id);

	public QuesAdding getQuesAdding(int id);

	public QuesAdding updateQuesAdding(QuesAdding ques);
}

