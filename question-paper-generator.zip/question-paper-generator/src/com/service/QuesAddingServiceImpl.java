package com.service;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.dao.QuesAddingDAO;
import com.model.QuesAdding;

@Service
@Transactional
public class QuesAddingServiceImpl implements QuesAddingService {

	@Autowired
	private QuesAddingDAO questionsDAO;

	@Transactional
	public void addQuesAdding(QuesAdding questions) {
		questionsDAO.addQuesAdding(questions);
	}

	@Transactional
	public void deleteQuesAdding(Integer questionsId) {
		questionsDAO.deleteQuesAdding(questionsId);
	}

	public QuesAdding getQuesAdding(int quesid) {
		return questionsDAO.getQuesAdding(quesid);
	}

	public QuesAdding updateQuesAdding(QuesAdding questions) {
		// TODO Auto-generated method stub
		return questionsDAO.updateQuesAdding(questions);
	}

	public void setQuesAddingDAO(QuesAddingDAO questionsDAO) {
		this.questionsDAO = questionsDAO;
	}

	@Transactional
	public List<QuesAdding> getAllQuesAdding() {
		// TODO Auto-generated method stub
		return questionsDAO.getAllQuesAdding();

}
}
