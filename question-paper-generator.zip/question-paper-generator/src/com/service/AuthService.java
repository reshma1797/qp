
package com.service;

import java.util.List;




import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.springframework.orm.hibernate4.HibernateTemplate;

import com.model.User;
import com.model.Assessment;
import com.model.ExamModify;
import com.model.QuesAdding;
 
public class AuthService {
 
    private HibernateTemplate hibernateTemplate;
   
 
    private AuthService() { }
 
    public void setHibernateTemplate(HibernateTemplate hibernateTemplate) {
        this.hibernateTemplate = hibernateTemplate;
    }
 
    @SuppressWarnings( { "unchecked" } )
    public List<User> findUser(String userId, String upwd) {
    	 List<User> userObj=null;
       
        String sqlQuery = "from User where user_id=? and password=?";
      
        System.out.println("In the authentication service...user entered data " + userId + " pwd "+upwd);
    
        try {
          userObj = (List<User>) hibernateTemplate.find(sqlQuery, userId, upwd);
            System.out.println("User : "+userObj);
            if(userObj != null)
            {
            	System.out.println("userObject is not null... ");
                for (User obj : userObj)
                {
                     System.out.println("Id "+obj.getUserId());
                }

            }          
            
        } catch(Exception e) {
        	 System.out.println("Exception : "+e);
        	 return userObj;
                 
        }
        return userObj;
    }
 
  
	public boolean registeruser(User reg) {
		// TODO Auto-generated method stub
		System.out.println("Before database");
		System.out.println("reg data :"+reg.getFirstName());
     Session session = hibernateTemplate.getSessionFactory().openSession();
       session.save(reg);
		//hibernateTemplate.save(reg);
		System.out.println("After database");
		return true;
	}
	
	
	public List<QuesAdding> getAllQuesAdding() {
		
		System.out.println("In auth getAllQuesAdding...");
			String sqlQuery = new String("from QuesAdding");
		System.out.println("HibernateTemplate "+hibernateTemplate);
		@SuppressWarnings("unchecked")
		List<QuesAdding> userObjLst = (List<QuesAdding>) hibernateTemplate.find(sqlQuery);
        
        if(userObjLst != null)
        {
        	System.out.println("userObject is not null... ");
        }   
				
        return userObjLst;
	} 
	
	
	 
	public void addQuesAdding(QuesAdding ques) {
		     	
		Session session = hibernateTemplate.getSessionFactory().openSession();
		System.out.println("Current session "+session);
		
		 String sqlQuery1 = "INSERT INTO Question (question_creator,question,choice_1,choice_2,choice_3,choice_4,selection,skill_set,competency_level,mark,answer) VALUES  (?,?,?,?,?,?,?,?,?,?,?)";
		 
		 session.beginTransaction();

		 SQLQuery insertQuery = session.createSQLQuery(sqlQuery1);
		 
		insertQuery.setParameter(0,ques.getqCreator());
		insertQuery.setParameter(1,ques.getQuestion());
		insertQuery.setParameter(2,ques.getA());
		insertQuery.setParameter(3,ques.getB());
		insertQuery.setParameter(4,ques.getC());
		insertQuery.setParameter(5,ques.getD());
		insertQuery.setParameter(6,ques.getSelection());
		insertQuery.setParameter(7,ques.getSkill());
		insertQuery.setParameter(8,ques.getLevel());
		insertQuery.setParameter(9,ques.getAnswer());
		insertQuery.setParameter(10, ques.getMark());
		 
		 insertQuery.executeUpdate();
		 session.getTransaction().commit();
	}
	
	public void deleteQuesAdding(Integer id) {
		 
		hibernateTemplate.bulkUpdate("DELETE FROM QuesAdding where qId ="+id);
		  
 	}
	
	public QuesAdding getQuesAdding(int id) {
		String sqlQuery = new String("from QuesAdding where qId = ?");
		@SuppressWarnings("unchecked")
		List<QuesAdding> userObjLst = (List<QuesAdding>) hibernateTemplate.find(sqlQuery,id);
		
		QuesAdding QuesObj=null;
		for (QuesAdding QuesObj1 : userObjLst)
		{
			  QuesObj = QuesObj1;
		}
		
		return QuesObj;

		//return (QuesAdding) sessionFactory.getCurrentSession().get(QuesAdding.class,id);
	}
	
	@SuppressWarnings("unchecked")
	public List<QuesAdding> fetchQuestion(String skill,String level) {
		List<QuesAdding> userObjLst=null;
		 try{
			  String sqlQuery = "from QuesAdding where skill=? and level=? order by rand()"; 
			  
			  System.out.println("In the authentication service...user entered data " + skill + " pwd "+level);
			   userObjLst = (List<QuesAdding>) hibernateTemplate.find(sqlQuery,skill,level);
			 
			   userObjLst=userObjLst.subList(0, 20);
			  if(userObjLst != null)
	            {
	            	System.out.println("Question obj is not null... ");
	            }
		  }
		  catch(Exception e)
		  {
			  System.out.println("Exception occur during Fetching question :"+e);
		  }
		return userObjLst;

		
	}
	
	public QuesAdding updateQuesAdding(QuesAdding ques) {
		//sessionFactory.getCurrentSession().update(ques);
		Session session = hibernateTemplate.getSessionFactory().openSession();
		System.out.println("Current session "+session);
		
		 String sqlQuery1 = "update Question SET choice_1 =?,choice_2=?,choice_3=?,choice_4=?,mark=?,question=?,selection=?,skill_set=?,answer=?,competency_level=?,question_creator=? WHERE question_id=?";
		 
		 session.beginTransaction();

		 SQLQuery insertQuery = session.createSQLQuery(sqlQuery1);
		insertQuery.setParameter(0, ques.getA());
		insertQuery.setParameter(1,ques.getB());
		insertQuery.setParameter(2,ques.getC());
		insertQuery.setParameter(3,ques.getD());
		insertQuery.setParameter(4,ques.getMark());
		insertQuery.setParameter(5,ques.getQuestion());
		insertQuery.setParameter(6,ques.getSelection());
		insertQuery.setParameter(7,ques.getSkill());
		insertQuery.setParameter(8,ques.getAnswer());
		insertQuery.setParameter(9,ques.getLevel());
		insertQuery.setParameter(10,ques.getqCreator());
		insertQuery.setParameter(11,ques.getqId());
		 
		 insertQuery.executeUpdate();
		 session.getTransaction().commit();
		 
		
		return ques;
	}


public List<ExamModify> getAllExamModify() {
	
	System.out.println("In getAllExamModify...");
	String sqlQuery = new String("from ExamModify");
	System.out.println("HibernateTemplate "+hibernateTemplate);
	@SuppressWarnings("unchecked")
	List<ExamModify> userObjLst = (List<ExamModify>) hibernateTemplate.find(sqlQuery);
    
    if(userObjLst != null)
    {
    	System.out.println("userObject is not null... ");
    }   
			
    return userObjLst;
} 


 
public void addExamModify(ExamModify exam) {
	
	Session session = hibernateTemplate.getSessionFactory().openSession();
	System.out.println("Current session "+session);
	
	 String sqlQuery1 = "INSERT INTO exam (exam_id,exam_description,skill_set,competency_level) VALUES  (?,?,?,?)";
	 
	 session.beginTransaction();

	 SQLQuery insertQuery = session.createSQLQuery(sqlQuery1);
	 
	insertQuery.setParameter(0, exam.geteId());
	insertQuery.setParameter(1, exam.getExam_name());
	insertQuery.setParameter(2,exam.getSkill());
	insertQuery.setParameter(3,exam.getLevel());
	insertQuery.executeUpdate();
	 
	session.getTransaction().commit();
}

public void deleteExamModify(String id) {
	 
	hibernateTemplate.bulkUpdate("DELETE FROM ExamModify where eId ='"+id+"'");
	  
	}

public ExamModify getExamModify(String id) {
	String sqlQuery = new String("from ExamModify where eId = ?");
	@SuppressWarnings("unchecked")
	List<ExamModify> userObjLst = (List<ExamModify>) hibernateTemplate.find(sqlQuery,id);
	
	ExamModify ExamObj=null;
	for (ExamModify ExamObj1 : userObjLst)
	{
		  ExamObj = ExamObj1;
	}
	return ExamObj;

	
}

public ExamModify updateExamModify(ExamModify exam) {
	
	Session session = hibernateTemplate.getSessionFactory().openSession();
	System.out.println("Current session "+session);
	
	 String sqlQuery1 = "update exam SET exam_description=?,skill_set=?,competency_level=? WHERE exam_id=?";
	 
	 session.beginTransaction();

	 SQLQuery insertQuery = session.createSQLQuery(sqlQuery1);
	;
	insertQuery.setParameter(0,exam.getExam_name());
	insertQuery.setParameter(1,exam.getSkill());
	
	insertQuery.setParameter(2,exam.getLevel());
	insertQuery.setParameter(3,exam.geteId());
	 
	 insertQuery.executeUpdate();
	 session.getTransaction().commit();
	return exam;
}

@SuppressWarnings("unchecked")
public List<Assessment> addAssessment(Assessment asmt) {
	
	Session session = hibernateTemplate.getSessionFactory().openSession();
	System.out.println("Current session "+session);
	List<Assessment> assmt=null;
	 String sqlQuery1 = "INSERT INTO assessment (user_id,exam_id,exam_description,competency_level,score,start_time,stop_time) VALUES  (?,?,?,?,?,?,?)";
	 try{
	 session.beginTransaction();

	 SQLQuery insertQuery = session.createSQLQuery(sqlQuery1);
	 
	insertQuery.setParameter(0, asmt.getuId());
	insertQuery.setParameter(1, asmt.geteId());
	insertQuery.setParameter(2, asmt.getExamName());
	insertQuery.setParameter(3, asmt.getLevel());
	insertQuery.setParameter(4, asmt.getScore());
	insertQuery.setParameter(5, asmt.getStart());
	insertQuery.setParameter(6, asmt.getStop());
	insertQuery.executeUpdate();
	 
	session.getTransaction().commit();
	
	String sqlQuery2="from Assessment ORDER BY assessment_id DESC";
	
  assmt = (List<Assessment>) hibernateTemplate.find(sqlQuery2);
	 
	   assmt=assmt.subList(0, 1);
	  if(assmt != null)
      {
      	System.out.println("Question obj is not null... "+assmt);
      }
	  return assmt;
}
catch(Exception e)
{
	  System.out.println("Exception occur during Fetching question :"+e);
	  return assmt;
}
	
}

public List<Assessment> getAllAssessment(String uId) {
	
	System.out.println("In auth getAllAssessment...");
		String sqlQuery = new String("from Assessment where uId=?");
	System.out.println("HibernateTemplate "+hibernateTemplate);
	@SuppressWarnings("unchecked")
	List<Assessment> asmt = (List<Assessment>) hibernateTemplate.find(sqlQuery,uId);
    
    if(asmt != null)
    {
    	System.out.println("userObject is not null... ");
    }   
			
    return asmt;
} 


}
