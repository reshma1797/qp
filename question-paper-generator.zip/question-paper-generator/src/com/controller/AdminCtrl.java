package com.controller;


import java.util.List;


import javax.servlet.http.HttpServletRequest;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.model.Assessment;
import com.model.ExamModify;
import com.model.QuesAdding;
import com.service.AuthService;

@Component
@RequestMapping("/admin")
public class AdminCtrl {
	@Autowired
	private AuthService authenticateService; 

	public AdminCtrl() {
		System.out.println("AdminCtrl()");
	
	}
	
	
	@RequestMapping(value = "/", method = RequestMethod.GET)
	public ModelAndView showAdmin(ModelAndView model,HttpServletRequest request) {
		if(request.getSession().getAttribute("uId")==null||(request.getSession().getAttribute("emp")==null)){
			return new ModelAndView("redirect:/");
		}else if(request.getSession().getAttribute("emp").equals("A")){
        		
		
		//fetching exam table
		List<ExamModify> listExamModify = authenticateService.getAllExamModify();
				
		for (ExamModify e : listExamModify)
		{
			System.out.println(e.geteId());
		}
		model.addObject("listExamModify", listExamModify);
		model.setViewName("adminHome");
		return model;
		}
		else
		{
			return new ModelAndView("redirect:/");
		}
	}
	
	@RequestMapping(value = "", method = RequestMethod.GET)
	public ModelAndView showAdmin1(ModelAndView model,HttpServletRequest request) {
		if((request.getSession().getAttribute("uId")==null)||(request.getSession().getAttribute("emp")==null)){
			return new ModelAndView("redirect:/");
		}else if(request.getSession().getAttribute("emp").equals("A")){
        		
		
		//fetching exam table
		List<ExamModify> listExamModify = authenticateService.getAllExamModify();
				
		for (ExamModify e : listExamModify)
		{
			System.out.println(e.geteId());
		}
		model.addObject("listExamModify", listExamModify);
		model.setViewName("adminHome");
		return model;
		}
		else
		{
			return new ModelAndView("redirect:/");
		}
	}
	
	@RequestMapping(value = "/question", method = RequestMethod.GET)
	public ModelAndView showAdminQues(ModelAndView model,HttpServletRequest request) {
		if((request.getSession().getAttribute("uId")==null)||(request.getSession().getAttribute("emp")==null)){
			return new ModelAndView("redirect:/");
		}else if(request.getSession().getAttribute("emp").equals("A")){
        		
		//fetching question table
		List<QuesAdding> listQuesAdding =  authenticateService.getAllQuesAdding();
		for (QuesAdding e : listQuesAdding)
		{
			System.out.println(e.getqId());
		}
		model.addObject("listQuesAdding", listQuesAdding);
		
		model.setViewName("adminQuestion");
		return model;
		}
		else
		{
			return new ModelAndView("redirect:/");
		}
	}
	

	
	@RequestMapping(value = "/addExam", method = RequestMethod.GET)
	public ModelAndView addExam(ModelAndView model,HttpServletRequest request) {
		if(request.getSession().getAttribute("uId")==null||(request.getSession().getAttribute("emp")==null)){
			return new ModelAndView("redirect:/");
		}else if(request.getSession().getAttribute("emp").equals("A")){
        		
		ExamModify exam = new ExamModify();
		model.addObject("exam", exam);
		model.setViewName("addExam");
		return model;
		}
		else
		{
			return new ModelAndView("redirect:/");
		}
	}
	@RequestMapping(value = "/saveExam", method = RequestMethod.POST)
	public ModelAndView saveExamModify(@ModelAttribute ExamModify exam,HttpServletRequest request) {    	
		if(request.getSession().getAttribute("uId")==null||(request.getSession().getAttribute("emp")==null)){
			return new ModelAndView("redirect:/");
		}else if(request.getSession().getAttribute("emp").equals("A")){
        	
		if (exam.getId() == 0) { // if employee id is 0 then creating table employee other updating the employee
			authenticateService.addExamModify(exam);
		} else {
			authenticateService.updateExamModify(exam);
		}
		return new ModelAndView("redirect:/admin/");
		}
		else
		{
			return new ModelAndView("redirect:/");
		}
	}
	
	@RequestMapping(value = "/deleteExam", method = RequestMethod.GET)
	public ModelAndView deleteExam(HttpServletRequest request) {
		System.out.println("Inside /deleteExamModify...");
		if(request.getSession().getAttribute("uId")==null||(request.getSession().getAttribute("emp")==null)){
			return new ModelAndView("redirect:/");
		}else if(request.getSession().getAttribute("emp").equals("A")){
        
		String id =request.getParameter("eId");
		
		authenticateService.deleteExamModify(id);
		return new ModelAndView("redirect:/admin/");
	}
	else
	{
		return new ModelAndView("redirect:/");
	}
	}
	
	@RequestMapping(value = "/editExam", method = RequestMethod.GET)
	public ModelAndView editExam(HttpServletRequest request) {
		if(request.getSession().getAttribute("uId")==null||(request.getSession().getAttribute("emp")==null)){
			return new ModelAndView("redirect:/");
		}else if(request.getSession().getAttribute("emp").equals("A")){
        
		String id =request.getParameter("eId");
		
		ExamModify exam = authenticateService.getExamModify(id);
		ModelAndView model = new ModelAndView("addExam");
		model.addObject("exam", exam);

		return model;
		}
		else
		{
			return new ModelAndView("redirect:/");
		}
	}
	
	@RequestMapping(value = "/addQuestion", method = RequestMethod.GET)
	public ModelAndView addQuestion(ModelAndView model,HttpServletRequest request) {
		if(request.getSession().getAttribute("uId")==null||(request.getSession().getAttribute("emp")==null)){
			return new ModelAndView("redirect:/");
		}else if(request.getSession().getAttribute("emp").equals("A")){
        
		String skill =request.getParameter("skill");
		String level =request.getParameter("level");
		QuesAdding ques = new QuesAdding();
		ques.setSkill(skill);
		ques.setLevel(level);
		model.addObject("ques", ques);
		model.setViewName("addQuestion");
		return model;
	}
	else
	{
		return new ModelAndView("redirect:/");
	}
	}
	@RequestMapping(value = "/saveQuestion", method = RequestMethod.POST)
	public ModelAndView saveQuesAdding(@ModelAttribute QuesAdding ques,HttpServletRequest request) {
		System.out.println("Id before saving..."+ques.getQuestion());
		if(request.getSession().getAttribute("uId")==null||(request.getSession().getAttribute("emp")==null)){
			return new ModelAndView("redirect:/");
		}else if(request.getSession().getAttribute("emp").equals("A")){
        
		ques.setqCreator((String) request.getSession().getAttribute("uname"));
		if (ques.getqId() == 0) {
		
			authenticateService.addQuesAdding(ques);

		} else {
			authenticateService.updateQuesAdding(ques);
		}
		return new ModelAndView("redirect:/admin/question");
		}
		else
		{
			return new ModelAndView("redirect:/");
		}
	}
	

	@RequestMapping(value = "/deleteQuestion", method = RequestMethod.GET)
	public ModelAndView deleteQuesAdding(HttpServletRequest request) {
		System.out.println("Inside /deleteQuesAdding...");
		if(request.getSession().getAttribute("uId")==null||(request.getSession().getAttribute("emp")==null)){
			return new ModelAndView("redirect:/");
		}else if(request.getSession().getAttribute("emp").equals("A")){
        
		int id = Integer.parseInt(request.getParameter("id"));

		authenticateService.deleteQuesAdding(id);
		return new ModelAndView("redirect:/admin/question");
	}
	else
	{
		return new ModelAndView("redirect:/");
	}
	}
	
	@RequestMapping(value = "/editQuestion", method = RequestMethod.GET)
	public ModelAndView editQuestion(HttpServletRequest request) {
		if(request.getSession().getAttribute("uId")==null||(request.getSession().getAttribute("emp")==null)){
			return new ModelAndView("redirect:/");
		}else if(request.getSession().getAttribute("emp").equals("A")){
        
		int id = Integer.parseInt(request.getParameter("id"));

		System.out.println("In /editQuesAdding..");

		QuesAdding ques = authenticateService.getQuesAdding(id);
		ModelAndView model = new ModelAndView("addQuestion");
		model.addObject("ques", ques);

		return model;
		}
		else
		{
			return new ModelAndView("redirect:/");
		}
	}
	
	@RequestMapping(value = "/issue", method = RequestMethod.GET)
	public ModelAndView showProfile(ModelAndView model,HttpServletRequest request) {
		if(request.getSession().getAttribute("uId")==null||(request.getSession().getAttribute("emp")==null)){
			return new ModelAndView("redirect:/");
		}else if(request.getSession().getAttribute("emp").equals("A")){
			//fetching exam table
			List<Assessment> ListAsmt = authenticateService.getAssessmentIssue("yes");
					
			System.out.println("asmt : "+ListAsmt);
			
			model.addObject("ListAsmt", ListAsmt);
			model.setViewName("adminIssue");
			return model;
		
		}
		else
		{
			return new ModelAndView("redirect:/");
		}
	}

}
