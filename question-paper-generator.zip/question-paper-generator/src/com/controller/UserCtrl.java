package com.controller;


import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;



import javax.servlet.http.HttpServletRequest;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.model.Assessment;
import com.model.ExamModify;
import com.model.QuesAdding;
import com.service.AuthService;
 

@Component
@RequestMapping("/user")
public class UserCtrl {
	@Autowired
	private AuthService authenticateService; 

	public UserCtrl() {
		System.out.println("UserCtrl()");
	}
	
	@RequestMapping(value = "/", method = RequestMethod.GET)
	public ModelAndView showUser(ModelAndView model,HttpServletRequest request) {
		if(request.getSession().getAttribute("uId")==null||(request.getSession().getAttribute("emp")==null)){
			return new ModelAndView("redirect:/");
		}else if(request.getSession().getAttribute("emp").equals("U")){
	
			return new ModelAndView("userHome");
		}
		else
		{
			return new ModelAndView("redirect:/question-paper-generator/");
		}
	}
	@RequestMapping(value = "", method = RequestMethod.GET)
	public ModelAndView showUser1(ModelAndView model,HttpServletRequest request) {
		if(request.getSession().getAttribute("uId")==null||(request.getSession().getAttribute("emp")==null)){
			return new ModelAndView("redirect:/");
		}else if(request.getSession().getAttribute("emp").equals("U")){
			return new ModelAndView("userHome");
		}
		else
		{
			return new ModelAndView("redirect:/question-paper-generator/");
		}
	}
	 
	@RequestMapping(value = "/searchSkill", method = RequestMethod.GET)
	public ModelAndView showAdmin(ModelAndView model,HttpServletRequest request) {
		if(request.getSession().getAttribute("uId")==null||(request.getSession().getAttribute("emp")==null)){
			return new ModelAndView("redirect:/");
		}else if(request.getSession().getAttribute("emp").equals("U")){
        		
		
		//fetching exam table
		List<ExamModify> listExamModify = authenticateService.getAllExamModify();
				
		for (ExamModify e : listExamModify)
		{
			System.out.println(e.geteId());
		}
		model.addObject("listExamModify", listExamModify);
		model.setViewName("searchSkill");
		return model;
		}
		else
		{
			return new ModelAndView("redirect:/question-paper-generator/");
		}
	}
	
	@RequestMapping(value = "/profile", method = RequestMethod.GET)
	public ModelAndView showProfile(ModelAndView model,HttpServletRequest request) {
		if(request.getSession().getAttribute("uId")==null||(request.getSession().getAttribute("emp")==null)){
			return new ModelAndView("redirect:/");
		}else if(request.getSession().getAttribute("emp").equals("U")){
			//fetching exam table
			List<Assessment> ListAsmt = authenticateService.getAllAssessment((String) request.getSession().getAttribute("uId"));
					
			System.out.println("asmt : "+ListAsmt);
			
			model.addObject("ListAsmt", ListAsmt);
			model.setViewName("reportProfile");
			return model;
		
		}
		else
		{
			return new ModelAndView("redirect:/question-paper-generator/");
		}
	}
	
	
	@RequestMapping(value = "/ins", method = RequestMethod.POST)
	public ModelAndView showIns(ModelAndView model,HttpServletRequest request,@RequestParam("skill")String skill,@RequestParam("eid")String eid,@RequestParam("desc")String desc, @RequestParam("level")String level) {
		if(request.getSession().getAttribute("uId")==null||(request.getSession().getAttribute("emp")==null)){
			return new ModelAndView("redirect:/");
		}else if(request.getSession().getAttribute("emp").equals("U")){
			
				
			model.addObject("eid",eid);
			model.addObject("desc",desc);
			model.addObject("skill",skill);
			model.addObject("level",level);
			model.setViewName("instruction");
			return model;
		}
		else
		{
			return new ModelAndView("redirect:/");
		}
	}
	
	@RequestMapping(value = "/test", method = RequestMethod.POST)
	public ModelAndView showTest(ModelAndView model,HttpServletRequest request,@RequestParam("skill")String skill,@RequestParam("eid")String eid,@RequestParam("desc")String desc, @RequestParam("level")String level) {
		if(request.getSession().getAttribute("uId")==null||(request.getSession().getAttribute("emp")==null)){
			return new ModelAndView("redirect:/");
		}else if(request.getSession().getAttribute("emp").equals("U")){
			List<QuesAdding> ques=authenticateService.fetchQuestion(skill, level);
			model.addObject("eid",eid);
			model.addObject("desc",desc);
			model.addObject("skill",skill);
			model.addObject("level",level);
	    	model.addObject("questionList",ques);
			model.setViewName("test");
			return model;
		}
		else
		{
			return new ModelAndView("redirect:/question-paper-generator/");
		}
	}
	
	@RequestMapping(value = "/summary", method = RequestMethod.POST)
	public ModelAndView showSummary(ModelAndView model,HttpServletRequest request,@RequestParam("eid")String eid,@RequestParam("ans")String ans,@RequestParam("unans")String unans,@RequestParam("level")String level,@RequestParam("score")String score,@RequestParam("desc")String examName,@RequestParam("start")String start,@RequestParam("stop")String stop) throws ParseException {
		if(request.getSession().getAttribute("uId")==null||(request.getSession().getAttribute("emp")==null)){
			return new ModelAndView("redirect:/");
		}else if(request.getSession().getAttribute("emp").equals("U")){
			System.out.println("EID :"+eid);
			DateFormat formatter=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			Date start1=formatter.parse(start);
			Date stop1=formatter.parse(stop);
			Assessment asmt=new Assessment();
			asmt.seteId(eid);
			asmt.setuId((String) request.getSession().getAttribute("uId"));
			asmt.setExamName(examName);
			asmt.setLevel(level);
			asmt.setScore(Integer.parseInt(score));
			asmt.setIssue("");
			asmt.setIssueRaised("no");
			asmt.setStart(start1);
			asmt.setStop(stop1);
			List<Assessment> assmt=authenticateService.addAssessment(asmt);
			
		System.out.println("assessment Summary" );
		model.addObject("asmt",assmt);
		model.addObject("ans",ans);
		model.addObject("unans",unans);
			model.setViewName("summary");
			return model;
		}
		else
		{
			return new ModelAndView("redirect:/");
		}
	}
	
	@RequestMapping(value = "/submitIssue", method = RequestMethod.POST)
	public ModelAndView submitIssue(ModelAndView model,HttpServletRequest request,@RequestParam("issue")String issue,@RequestParam("aid")String aid) {
		if(request.getSession().getAttribute("uId")==null||(request.getSession().getAttribute("emp")==null)){
			return new ModelAndView("redirect:/");
		}else if(request.getSession().getAttribute("emp").equals("U")){
			boolean res=authenticateService.updateIssue(aid,issue);
			if(res)
			model.setViewName("redirect:/user/profile");
			else
				model.setViewName("redirect:/user/");	
			return model;
		}
		else
		{
			return new ModelAndView("redirect:/question-paper-generator/");
		}
	}
}
