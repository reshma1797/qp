package com.controller;
import javax.servlet.http.HttpServletRequest;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
 
import java.util.List;
import com.model.User;
import com.service.AuthService;
 
@Controller
@RequestMapping("/auth")

public class LoginCtrl {
	 @Autowired
	    private AuthService authenticateService;            
	 // This will auto-inject the authentication service into the controller.
	 
	//forward to login page
	 @RequestMapping(value = "/login")
	    public ModelAndView forwardLogin() {
	            return new ModelAndView("login","msg","");
	        }
	 
	    // Checks if the user credentials are valid or not.
	    @RequestMapping(value = "/validate", method = RequestMethod.POST)
	    public ModelAndView validateUsr(ModelAndView model,HttpServletRequest request,@RequestParam("userid")String userId, @RequestParam("password")String password) {
	        String msg = "";
	        List<User> userObj = authenticateService.findUser(userId, password);

	        if(userObj!=null) {
	            msg = "Welcome " + userId + "!";
	            for (User obj : userObj)
                {
	            	if (obj.getEmpType().equals("A")){
	            		request.getSession().setAttribute("uId",obj.getUserId());
	            		String uname=obj.getFirstName()+" "+obj.getLastName();
	            		request.getSession().setAttribute("uname",uname);
	            		request.getSession().setAttribute("emp",obj.getEmpType());
	            		System.out.println("uname :"+uname);
	 	               return new ModelAndView("redirect:/admin/");
	            	}
	            	else{
	            		request.getSession().setAttribute("uId",obj.getUserId());
	            		String uname=obj.getFirstName()+" "+obj.getLastName();
	            		request.getSession().setAttribute("uname",uname);
	            		request.getSession().setAttribute("email",obj.getEmail());
	            		request.getSession().setAttribute("emp",obj.getEmpType());
	            		return new ModelAndView("redirect:/user/");
	            	}
                }
	           
	            
	        } 
	            msg = "Invalid credentials";
	            model.addObject("msg",msg);
	            model.addObject("type","red");
	            model.setViewName("login");
	            return model;
	      
	 
	     
	    }
	    
	    //logout
	    
	    
		 @RequestMapping(value = "/logout")
			public ModelAndView logoutFunction(HttpServletRequest request)
			{
			 request.getSession().setAttribute("uId",null);
			 request.getSession().setAttribute("emp",null);
			 return new ModelAndView("redirect:/");
			}
	    
	    //testing for register
	    
	    @RequestMapping(value = "/register")
		public ModelAndView redirectregister(@RequestParam("msg")String msg)
		{
	    	ModelAndView model=new ModelAndView();
	    	model.addObject("User_Type","User");
	    	model.addObject("hme","/question-paper-generator/");
	    	model.addObject("msg",msg);
	    	model.setViewName("register");
			return model;
		}
	    //EmployeeType
		 
		 @RequestMapping(value = "/signUpAdmin")
			public ModelAndView AdminReg(HttpServletRequest request,@RequestParam("msg")String msg)
			{
			 if(request.getSession().getAttribute("uId")==null||(request.getSession().getAttribute("emp")==null)){
					return new ModelAndView("redirect:/");
				}else if(request.getSession().getAttribute("emp").equals("A")){
		        
			 ModelAndView model=new ModelAndView();
		    	model.addObject("User_Type","Admin");
		    	model.addObject("hme","/question-paper-generator/admin/");
		    	model.addObject("msg",msg);
		    	model.setViewName("register");
				return model;
				}
				else
				{
					return new ModelAndView("redirect:/");
				}
			}
		
		 @RequestMapping(value = "/registerProcess", method = RequestMethod.POST)
		    public ModelAndView RegisterUsr(ModelAndView model,@RequestParam("userid")String userId,@RequestParam("firstname")String firstname, @RequestParam("lastname")String lastname,@RequestParam("email")String email,@RequestParam("password")String psw,@RequestParam("emptype")String emptype) {
		       
		     System.out.println("Inside /registerProcess...");	
			 System.out.println("Emp type "+emptype);
		    	User reg = new User();
		    	reg.setUserId(userId);
		        reg.setEmail(email);
		        reg.setFirstName(firstname);
		        reg.setLastName(lastname);
		        reg.setPassword(psw);
		        reg.setEmpType(emptype);		       
		      
		        boolean isValid = authenticateService.registeruser(reg);
	
		        if(isValid) {
		        	if(reg.getEmpType().equals("A")){
		        		System.out.println(reg.getEmpType());
		        		 String msg = "Admin Successfully Registered";
		 	            model.addObject("msg",msg);
		 	            model.addObject("type","Green");
		 	            model.setViewName("redirect:/admin/");
		 	            return model;
		        		
				      }
		        	else{

		        		System.out.println("user type :"+reg.getEmpType());
		        		String msg = "User Successfully Registered";
		 	            model.addObject("msg",msg);
		 	            model.addObject("type","Green");
		 	            model.setViewName("login");
		 	            return model;
		        	}
		        } 
		        else {
		        	if(reg.getEmpType().equals("A")){
		        		model.addObject("msg","true");
		        		model.setViewName("redirect:/auth/signUpAdmin");
		        		return model;
				      }
		        	else{
		        		model.addObject("msg","true");
		        		model.setViewName("redirect:/auth/register");
		        		return model;
		        	}
		        }
		 
		        
		    }
		 
		 
		
		
	}


