package com.controller;
import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpRequest;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;


import javax.servlet.http.HttpSession;  
import java.util.List;
import com.model.User;
import com.service.AuthService;
 
@Controller
@RequestMapping("/auth")

public class LoginCtrl {
	 @Autowired
	    private AuthService authenticateService;            
	 // This will auto-inject the authentication service into the controller.
	 
	//forward to login page
	 @RequestMapping(value = "/login")
	    public ModelAndView forwardLogin() {
	            return new ModelAndView("login");
	        }
	 
	    // Checks if the user credentials are valid or not.
	    @SuppressWarnings("null")
		@RequestMapping(value = "/validate", method = RequestMethod.POST)
	    public ModelAndView validateUsr(HttpServletRequest request,@RequestParam("userid")String userId, @RequestParam("password")String password) {
	        String msg = "";
	        List<User> userObj = authenticateService.findUser(userId, password);

	        if(userObj!=null) {
	            msg = "Welcome " + userId + "!";
	            for (User obj : userObj)
                {
	            	if (obj.getEmpType().equals("A")){
	            		request.getSession().setAttribute("uname",obj.getUserId());
	            		request.getSession().setAttribute("emp",obj.getEmpType());
	 	               return new ModelAndView("redirect:/admin/");
	            	}
	            	else{
	            		request.getSession().setAttribute("uname",obj.getUserId());
	  	              return new ModelAndView("result", "output", msg);
	            	}
                }
	           
	            
	        } 
	            msg = "Invalid credentials";
	            return new ModelAndView("login", "output", msg);
	      
	 
	     
	    }
	    
	    //logout
	    
	    
		 @RequestMapping(value = "/logout")
			public ModelAndView logoutFunction(HttpServletRequest request)
			{
			 request.getSession().setAttribute("uname",null);
			 request.getSession().setAttribute("emp",null);
			 return new ModelAndView("redirect:/");
			}
	    
	    //testing for register
	    
	    @RequestMapping(value = "/register")
		public ModelAndView redirectregister()
		{
	    	ModelAndView model=new ModelAndView();
	    	model.addObject("User_Type","User");
	    	model.addObject("hme","/question-paper-generator/");
	    	model.setViewName("register");
			return model;
		}
	    //EmployeeType
		 
		 @RequestMapping(value = "/signUpAdmin")
			public ModelAndView AdminReg()
			{
			 ModelAndView model=new ModelAndView();
		    	model.addObject("User_Type","Admin");
		    	model.addObject("hme","/question-paper-generator/admin/");
		    	model.setViewName("register");
				return model;
			}
		
		 @RequestMapping(value = "/registerProcess", method = RequestMethod.POST)
		    public ModelAndView RegisterUsr(@RequestParam("userid")String userId,@RequestParam("firstname")String firstname, @RequestParam("lastname")String lastname,@RequestParam("email")String email,@RequestParam("password")String psw,@RequestParam("emptype")String emptype) {
		       
		     System.out.println("Inside /registerProcess...");	
			 System.out.println("Emp type "+emptype);
		    	User reg = new User();
		    	reg.setUserId(userId);
		        reg.setEmail(email);
		        reg.setFirstName(firstname);
		        reg.setLastName(lastname);
		        reg.setPassword(psw);
		        reg.setEmpType(emptype);		       
		      
		        boolean isValid = authenticateService.registeruser(reg);
	
		        if(isValid) {
		        	if(reg.getEmpType().equals("A")){
		        		System.out.println(reg.getEmpType());
		        		return new ModelAndView("redirect:/admin/");
				      }
		        	else{

		        		System.out.println("user type :"+reg.getEmpType());
		        	return new ModelAndView("redirect:/auth/login");
		        	}
		        } 
		        else {
		        	return new ModelAndView("redirect:/signUpAdmin/");
		        }
		 
		        
		    }
		 
		 
		
		
	}


