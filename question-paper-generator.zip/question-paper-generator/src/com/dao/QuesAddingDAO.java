package com.dao;
import java.util.List;


import com.model.QuesAdding;
import com.model.QuesAdding;

public interface QuesAddingDAO {
	public void addQuesAdding(QuesAdding ques);

	public List<QuesAdding> getAllQuesAdding();

	public void deleteQuesAdding(Integer id);

	public QuesAdding updateQuesAdding(QuesAdding ques);

	public QuesAdding getQuesAdding(int id);
	

}

