package com.model;

import java.io.Serializable;




public class QuesAdding implements Serializable {

		private static final long serialVersionUID = -3465813074586302847L;

		private int qId;	
		
	     private int mark;
	  private String qCreator;
	     public String getqCreator() {
		return qCreator;
	}

	public void setqCreator(String qCreator) {
		this.qCreator = qCreator;
	}

		private String question;
	 
	     private String  a;
	  
	     private String b;
	  
	     private String c;
	 
	     private String d;
	  
	     private String selection;
	    private String skill;
	  private String answer;
		private String level;
	     public String getAnswer() {
		return answer;
	}

	public void setAnswer(String answer) {
		this.answer = answer;
	}


	  
	     public int getqId() {
			return qId;
		}

		public void setqId(int qid) {
			this.qId = qid;
		}

		public String getQuestion() {
			return question;
		}

		public void setQuestion(String question) {
			this.question = question;
		}

		public String getA() {
			return a;
		}

		public void setA(String a) {
			this.a = a;
		}

		public String getB() {
			return b;
		}

		public void setB(String b) {
			this.b = b;
		}

		public String getC() {
			return c;
		}

		public void setC(String c) {
			this.c = c;
		}

		public String getD() {
			return d;
		}

		public void setD(String d) {
			this.d = d;
		}

		public String getSelection() {
			return selection;
		}

		public void setSelection(String selection) {
			this.selection = selection;
		}

		public String getSkill() {
			return skill;
		}

		public void setSkill(String skill) {
			this.skill = skill;
		}

		public String getLevel() {
			return level;
		}

		public void setLevel(String level) {
			this.level = level;
		}

		public static long getSerialversionuid() {
			return serialVersionUID;
		}

		public void setMark(int mark) {
			this.mark = mark;
		}

		public int getMark() {
			return mark;
		}

	

}