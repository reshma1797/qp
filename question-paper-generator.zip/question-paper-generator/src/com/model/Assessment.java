package com.model;

import java.io.Serializable;
import java.util.Date;

public class Assessment implements Serializable  {
	
	private static final long serialVersionUID = -3465813074586302846L;
	

	private int aId,score;
	
	private String examName,uId,eId,level;
	
	private Date start,stop;
	
	
	public String getExamName() {
		return examName;
	}


	public void setExamName(String examName) {
		this.examName = examName;
	}


	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	

	public int getaId() {
		return aId;
	}

	public void setaId(int aId) {
		this.aId = aId;
	}

	public int getScore() {
		return score;
	}

	public void setScore(int score) {
		this.score = score;
	}

	public String getuId() {
		return uId;
	}

	public void setuId(String uId) {
		this.uId = uId;
	}

	public String geteId() {
		return eId;
	}

	public void seteId(String eId) {
		this.eId = eId;
	}

	public String getLevel() {
		return level;
	}

	public void setLevel(String level) {
		this.level = level;
	}

	public Date getStart() {
		return start;
	}

	public void setStart(Date start) {
		this.start = start;
	}

	public Date getStop() {
		return stop;
	}

	@Override
	public String toString() {
		return "[aId='" + aId + "', score='" + score + "', examName='" + examName + "', uId='" + uId + "', eId='"
				+ eId + "', level='" + level + "', start='" + start + "', stop='" + stop+"']";
	}


	public void setStop(Date stop) {
		this.stop = stop;
	}

	
}
